package game;

public class Team{

    private final String teamName;

    public Team(String teamName) {
        this.teamName = teamName;
    }

    public String getName() {
        return teamName;
    }
}
